Create Table AdminAssistant
(
	AdminID varchar(30) NOT NULL Primary Key,
	AdminName varchar(30) NOT NULL ,
	UserName varchar(30) NOT NULL ,
	Email varchar(30) NOT NULL,
	Password varchar(30) NOT NULL,
	PhoneNumber varchar(30) NOT NULL,
	Address varchar(30) NOT NULL
);

Select * from AdminAssistant

Create Table ApplianceType
(
	ApplianceTypeID varchar (30) Not Null Primary Key,
	ApplianceTypeName varchar (30)
);

Select * from ApplianceType


Create Table Brand
(
	BrandID varchar (30) Not Null Primary Key,
	BrandName varchar (30)
);

Select * from Brand

Create Table Appliances
(
	ApplianceID varchar(30) Not Null Primary Key,
	ApplianceName varchar(30),
	BrandID varchar (30),
	ApplianceTypeID varchar (30),
	MonthlyPrice int,
	PowerUsage varchar(30),
	Model varchar(30),
	Color varchar(30),
	Description varchar (50),
	Images image,
	Foreign Key (BrandID) References Brand (BrandID),
	Foreign Key (ApplianceTypeID) References ApplianceType (ApplianceTypeID)
);

Select * from Appliances


/* Customer*/
Create Table Customers
(
	CustomerCodeNo varchar(30) NOT NULL Primary Key,
	CustomerName varchar(30) NOT NULL ,
	UserName varchar(30) NOT NULL ,
	Email varchar(30) NOT NULL,
	NRC varchar(30) NOT NULL,
	Password varchar(30) NOT NULL,
	PhoneNumber varchar(30) NOT NULL,
	Address varchar(30) NOT NULL
);

Select * from Customers

Create Table ARent
(
	RentID varchar(30) NOT NULL Primary Key,
	Rentdate varchar(50) NOT NULL ,
	RentItemQuantity int NOT NULL,
	TotalAmount int NOT NULL,
	CustomerCodeNo varchar(30) NOT NULL,
	Foreign Key (CustomerCodeNo) References Customers (CustomerCodeNo)
);

Select * From ARent
Select * From RentDetails

Create Table RentDetails
(
	RentID varchar(30) NOT NULL ,
	ApplianceID varchar(30) NOT NULL ,
	RentTotalItem int NOT NULL,
	RentAmount int NOT NULL,
	Primary Key (RentID,ApplianceID),
	Foreign Key (RentID) References ARent (RentID),
	Foreign Key (ApplianceID) References Appliances (ApplianceID)
);


Select * From RentDetails

Create Table Reviews
(
	ReviewID varchar(30) NOT NULL ,
	CustomerCodeNo varchar(30) NOT NULL ,
	Feedback varchar(30) NOT NULL,
	Rating varchar(30) NOT NULL,
	Primary Key (ReviewID),
	Foreign Key (CustomerCodeNo) References Customers (CustomerCodeNo)
);

Select * From Reviews




